<?php require_once('session.php'); ?>
<!doctype html>
<html class="no-js"  lang="en">

  <head>
    <!-- META DATA -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!--font-family-->
    <link href="https://fonts.googleapis.com/css?family=Rufina:400,700" rel="stylesheet" />

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet" />

    <!-- TITLE OF SITE -->
    <title>ASKMETRIP</title>

    <!-- favicon img -->
    <link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>

    <!--font-awesome.min.css-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />

    <!--animate.css-->
    <link rel="stylesheet" href="assets/css/animate.css" />

    <!--hover.css-->
    <link rel="stylesheet" href="assets/css/hover-min.css">

    <!--datepicker.css-->
    <link rel="stylesheet"  href="assets/css/datepicker.css" >

    <!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css"/>

    <!-- range css-->
        <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />

    <!--bootstrap.min.css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />

    <!-- bootsnav -->
    <link rel="stylesheet" href="assets/css/bootsnav.css"/>

    <!--style.css-->
    <link rel="stylesheet" href="assets/css/style.css" />

    <!--responsive.css-->
    <link rel="stylesheet" href="assets/css/responsive.css" />

    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>

<!-- include summernote css/js -->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>

  <body>
  <?php require_once('header_black.php'); ?>
  <?php
  echo $priv = $_SESSION['priv'];

  if (!isset($priv)) {
    echo "<script>location.href='login.php';</script>";
  }

  ?>
    <!-- main-menu End -->

<br><br><br><br>

 <section style=";text-align:center;">
  <div class="container">
  <div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12">
  <div>
      <div><h1><b>Manage Your Website!</b></h1></div>
  </div>
  </div>
  </div>
  </div>
  </section>


 <section id="aboutUs">
      <div class="container">
        <div class="row">
        <!-- Start about us area -->
        <div class="col-lg-9 col-md-9 col-sm-9">
          <div class="aboutus_area wow fadeInLeft" id="demo">
            <h2 >View All registration</h2>
          </div>
          <table style="width:100%">
            <tbody>
              <tr>
                <th>Destination</th>
                <th>Duration</th>
                <th>Date</th>
                <th>Added Destination</th>
              <tr>
              <?php



              ?>
            </tbody>
          </table>
        </div>



        <div class="col-lg-3 col-md-3 col-sm-3">
          <div class="newsfeed_area wow fadeInRight">
            <ul>
              <li style="font-size:20px;">Sections</li>
          </ul>
    </div>

            <!-- Tab panes -->
            <div class="tab-content">
              <!-- Start news tab content -->
              <div class="tab-pane fade in active" id="news">
                <ul class="news_tab">
                  <li style="border-bottom:none;"> </li>

                  <li>
                    <div class="media">
                      <div class="media-body" >
                       <a href="desc.php">Add a Destination</a>
                        </div>
                    </div>
                  </li>

                  <li>
                    <div class="media">
                       <div class="media-body">
                       <a href="view_Registration.php">See Registrations</a>
                      </div>
                    </div>
                  </li>
                   <li>
                    <div class="media">
                       <div class="media-body">
                       <a href="educational_trip.php" ">Educational Trip</a>

                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                       <div class="media-body">
                       <a href="change_password.php">Change Password</a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                       <div class="media-body">
                       <a href="logout.php">Logout</a>

                      </div>
                    </div>
                  </li>

                </ul>
</div>
              </div>
            </div>
            </div>
            </div>

              </section>




    <?php
    include('footer.php');
    ?>






    <!--modernizr.min.js-->
    <script  src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>


    <!--bootstrap.min.js-->
    <script  src="assets/js/bootstrap.min.js"></script>

    <!-- bootsnav js -->
    <script src="assets/js/bootsnav.js"></script>

    <!-- jquery.filterizr.min.js -->
    <script src="assets/js/jquery.filterizr.min.js"></script>

    <script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

    <!--jquery-ui.min.js-->
        <script src="assets/js/jquery-ui.min.js"></script>

        <!-- counter js -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>

    <!--owl.carousel.js-->
        <script  src="assets/js/owl.carousel.min.js"></script>

        <!-- jquery.sticky.js -->
    <script src="assets/js/jquery.sticky.js"></script>

        <!--datepicker.js-->
        <script  src="assets/js/datepicker.js"></script>

    <!--Custom JS-->
    <script src="assets/js/custom.js"></script>

    <script type="text/javascript">
      $(document).ready(function() {
  $('#summernote').summernote();
    });
    </script>

  </body>

</html>