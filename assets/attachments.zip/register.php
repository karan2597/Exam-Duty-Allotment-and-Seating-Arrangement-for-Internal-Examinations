<?php

include('connect.php');

$a = $_POST['to'];
$b = $_POST['from'];
$c = $_POST['check_in'];
$d = $_POST['check_out'];
$e = $_POST['duration'];
$f = $_POST['name'];
$g = $_POST['email'];
$h = $_POST['phone'];
$i = $_POST['stages'];
$j = $_POST['adult'];
$k = $_POST['children'];
$l = $_POST['budget'];
$m = $_POST['additional'];

$e = str_replace("'","\'",$i);

 $q_select="INSERT INTO `register`(`destination_to`,`destination_from`,`check_in`,`check_out`,`duration`,`name`,`email_id`,`phone_no`,`stage`,`adult`,`children`,`budget`,`additional`) VALUES ('$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k','$l','$m')";
$execute1=mysqli_query($con,$q_select)or exit($q_select);
?>